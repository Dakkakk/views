package zxr.sdk.views;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Spinner;
import android.widget.TextView;
import zxr.sdk.views.R;
import android.util.DisplayMetrics;

public class MainActivity extends Activity implements OnSeekBarChangeListener,OnItemSelectedListener,OnClickListener{

	@Override
	public void onItemSelected(AdapterView<?> view, View v, int index, long p4){
		TextView tv=(TextView) v;
		String str=(String) tv.getText();
		switch(view.getId()){
			case R.id.progressOrientation:
				bar.setProgressOrientation(ProgressBar.ProgressOrientation.valueOf(str));
				break;
			case R.id.textPosition:
				bar.setTextPosition(ProgressBar.TextPosition.valueOf(str));
				break;
			case R.id.textType:
				bar.setTextType(ProgressBar.TextType.valueOf(str));
				break;
		}
	}

	@Override
	public void onNothingSelected(AdapterView<?> view){
		// TODO: Implement this method
		
	}
	

	@Override
	public void onClick(View view){
		int id=view.getId();
		String progressColor=this.progressColor.getText().toString();
		Log.d("","|"+progressColor+"|");
		String backProgressColor=this.backProgressColor.getText().toString();
		Log.d("",""+(progressColor!=""));
		String progressSize=this.progressSize.getText().toString();
		String textColor=this.textColor.getText().toString();
		String textSize=this.textSize.getText().toString();
		if(go(progressColor)){
			bar.setProgressColor(Color.parseColor(progressColor));
		}
		if(go(backProgressColor)){
			bar.setBackgroundprogressColor(Color.parseColor(backProgressColor));
		}
		if(go(textColor)){
			bar.setTextColor(Color.parseColor(textColor));
		}
		if(go(progressSize)&&progressSize.contains(".")){
			bar.setProgressSize(Float.parseFloat(progressSize));
		}
		if(go(textSize)&&textSize.contains(".")){
			bar.setTextSize(Float.parseFloat(textSize));
		}
	}
	
	private boolean go(String str){
		return str!=null&&str!=""&&str.length()>0;
	}

	@Override
	public void onProgressChanged(SeekBar seekbar, int p, boolean t){
		bar.progress(p);
	}

	@Override
	public void onStartTrackingTouch(SeekBar seekbar){
		
	}

	@Override
	public void onStopTrackingTouch(SeekBar seekbar){
		// TODO: Implement this method
	}

    private EditText progressColor,backProgressColor,progressSize,textColor,textSize;
	private SeekBar seekBar;
	private Spinner textPosition,textType,progressOrientation;
	private ProgressBar bar;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
		init1();
		seekBar.setOnSeekBarChangeListener(this);
		textType.setAdapter(getarray(R.array.textType));
		textPosition.setAdapter(getarray(R.array.textPosition));
		progressOrientation.setAdapter(getarray(R.array.progressOrientation));
		textType.setOnItemSelectedListener(this);
		textPosition.setOnItemSelectedListener(this);
		progressOrientation.setOnItemSelectedListener(this);
		bar.setMax(100);
		bar.progress(0);
		seekBar.setMax(100);
	}
	
	private ArrayAdapter<String> getarray(int resId){
		ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,R.layout.m);
		for(String str:getResources().getStringArray(resId)){
			adapter.add(str);
		}
		return adapter;
	}

	private void init1(){
		ViewGroup vg=(ViewGroup) getLayoutInflater().inflate(R.layout.main, null);
		bar=new ProgressBar(this);
		vg.addView(bar);
		setContentView(vg);
		progressColor=(EditText) findViewById(R.id.progressColor);
		backProgressColor=(EditText) findViewById(R.id.backProgressColor);
		progressSize=(EditText) findViewById(R.id.progressSize);
		textSize=(EditText) findViewById(R.id.textSize);
		textColor=(EditText) findViewById(R.id.textColor);
		seekBar=(SeekBar) findViewById(R.id.SeekBar);
		textPosition=(Spinner) findViewById(R.id.textPosition);
		textType=(Spinner) findViewById(R.id.textType);
		progressOrientation=(Spinner) findViewById(R.id.progressOrientation);
		((Button)findViewById(R.id.done)).setOnClickListener(this);
	}
}
