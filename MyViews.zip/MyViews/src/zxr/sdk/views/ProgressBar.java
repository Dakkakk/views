package zxr.sdk.views;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;
import android.util.Log;
import android.graphics.Bitmap;
import android.util.TypedValue;
import android.util.DisplayMetrics;
import android.app.Activity;
import android.graphics.Rect;

public class ProgressBar extends View{
	//the max 
	private int max_value=206;
	//progress 
	private int value=100;
	//font
	private Typeface font;
	//show type
	private TextType textType=TextType.PERCENT;
	//where to draw text
	private TextPosition position=TextPosition.WITHPROGRESS;
	private int textColor=Color.BLUE;
	private int progressColor=Color.BLUE;
	private float progressSize=50;
	private float textSize=32;
	private int backgroundprogressColor=Color.DKGRAY;
	//when position set to point,
	//it will use textPosition
	private PointF textPosition=new PointF(60.7f, 60.7f);
	private ProgressOrientation orientation=ProgressOrientation.HORIZONTAL;
	public float dip2px( float dpValue) {
         float scale = getResources().getDisplayMetrics().density;
        return  dpValue * scale + 0.5f;

    }
	
    public float sp2px( float spValue) {
      DisplayMetrics dm = new DisplayMetrics();
   ((Activity)  getContext()) .getWindowManager().getDefaultDisplay().getMetrics(dm);
      float fontScale = dm.scaledDensity;
      return  (spValue * fontScale + 0.5f);
       // float px =  TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, spValue, getResources().getDisplayMetrics());
     //   return px; 
		}
		
	private void rotate(Canvas c, float angle){
		c.rotate(angle, getWidth() / 2, getHeight() / 2);
	}

	@Override
	protected void onDraw(Canvas canvas){
		boolean willRotate=false;
		if (orientation == ProgressOrientation.HORIZONTAL_DE || orientation == ProgressOrientation.VERTICAL_DE){
			willRotate=true;
			rotate(canvas, 180);
		}
		Paint paint=new Paint();
		paint.setColor(Color.GREEN);
		PointF point=drawProgress(canvas);
		if (willRotate)
			rotate(canvas, 180);
		drawText(canvas, point);

		super.onDraw(canvas);
	}

	private void drawText(Canvas canvas, PointF point){
		setTextPosition(TextPosition.WITHPROGRESS);
		setProgressOrientation(ProgressOrientation.HORIZONTAL);
		Paint paint=new Paint();
		paint.setAntiAlias(true);
		float x,y;
		
		paint.setTextSize(textSize);
		String text=getText();
		if (position == TextPosition.POINT){
			x=textPosition.x;
			y=textPosition.y;
		}
		else{
			if (ProgressOrientation.HORIZONTAL == orientation || ProgressOrientation.HORIZONTAL_DE == orientation){
				x=point.x;
				y=point.y;
				setTextSize(40.5f);
				Rect f=new Rect();
				paint.getTextBounds(text,0,text.length(),f);
				RectF ff=new RectF(f.top+93,f.left,f.right+90,f.bottom);
				float t=ff.right-ff.left;
				canvas.drawLine(ff.left,ff.top+50,ff.right,ff.bottom+50,paint);
			}
			else{
				x=point.x;
				y=point.y + textSize;
			}
		}
		paint.setColor(textColor);
		canvas.drawText(text, x, y, paint);
	}

	private String getText(){
		if (textType == TextType.NORMAL)
			return value + "||" + max_value;
		else
			return String.format("%.2f", 100 * (float)value / max_value) + "%";
	}

	private PointF drawProgress(Canvas canvas){
		PointF pointF=new PointF(88, 88);
		Paint paint=new Paint();
		paint.setAntiAlias(true);
		paint.setColor(backgroundprogressColor);
		float x0,y0;
		float x1,y1;
		float x2,y2;
		RectF rect0=new RectF();
		RectF rect1=new RectF();
		if (orientation == ProgressOrientation.VERTICAL || orientation == ProgressOrientation.VERTICAL_DE){
			float distence=progressSize / 2;
			float d2=getWidth() / 2;
			x0=x1 = x2 = d2;
			y0=getHeight() / 300 + distence;
			y2=getHeight() - y0;
			y1=(float)value / max_value * (y2 - y0) + y0;
			rect0.set(d2 - distence, y0, d2 + distence, y2);
			rect1.set(d2 - distence, y0, d2 + distence, y1);
			pointF.set(x1, y1);
		}
		else{
			float distence=progressSize / 2;
			float d2=getHeight() / 2;
			x0=getWidth() / 300 + distence;
			y0=y1 = y2 = d2;
			x2=getWidth() - x0;
			x1=(float)value / max_value * (x2 - x0) + x0;
			rect0.set(x0, d2 - distence, x2, d2 + distence);
			rect1.set(x0, d2 - distence, x1, d2 + distence);
		}
		//backgroundprogress drawing

		canvas.drawCircle(x2, y2, progressSize / 2, paint);
		canvas.drawRect(rect0, paint);
		//******************************************************
		paint.setColor(progressColor);
		canvas.drawCircle(x0, y0, progressSize / 2, paint);
		canvas.drawCircle(x1, y1, progressSize / 2, paint);
		canvas.drawRect(rect1, paint);
		return pointF;
	}

	public ProgressOrientation setProgressOrientation(ProgressOrientation orientation){
		this.orientation=orientation;
		invalidate();
		return orientation;
	}

	public PointF setTextPosition(PointF textPosition){
			this.textPosition=textPosition;
			invalidate();
			return textPosition;
	}

	public int setBackgroundprogressColor(int backgroundprogressColor){
		this.backgroundprogressColor=backgroundprogressColor;
		invalidate();
		return backgroundprogressColor;
	}

	public float setProgressSize(float progressSize){
		this.progressSize=progressSize;
		invalidate();
		return progressSize;
	}

	public int setProgressColor(int progressColor){
		this.progressColor=progressColor;
		invalidate();
		return progressColor;
	}

	public TextType setTextType(TextType textType){
			this.textType=textType;
			invalidate();
			return textType;
	}

	public TextPosition setTextPosition(TextPosition position){
		this.position=position;
		invalidate();
		return position;
	}

	public int setTextColor(int color){
			this.textColor=color;
			invalidate();
			return color;
	}

	public float setTextSize(float size){
		this.textSize=size;
		invalidate();
		return size;
	}

	public void setMax(int max){
		this.max_value=max;
		invalidate();
	}

	public void progress(int progress){
		if (0 <= progress && progress <= max_value){
			this.value=progress;
			this.invalidate();
		}
	}

	public Typeface setTypeface(Typeface typeface){
		this.font=typeface;
		invalidate();
		return typeface;
	}

	public ProgressBar(Context activity){
		super(activity);

	}

	public static enum TextPosition{
		POINT,
		WITHPROGRESS,
		WITHPROGRESS_ON
		}

	public static enum TextType{
		PERCENT,
		NORMAL
		}

	public static enum ProgressOrientation{
		VERTICAL,
		HORIZONTAL,
		VERTICAL_DE,
		HORIZONTAL_DE
		}
}
